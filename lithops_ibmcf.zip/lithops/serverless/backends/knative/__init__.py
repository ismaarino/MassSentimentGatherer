from .knative import KnativeServingBackend as ServerlessBackend
